When $MPL = 0$ or $\frac{\delta Q}{\delta L} = MPL = 0$
