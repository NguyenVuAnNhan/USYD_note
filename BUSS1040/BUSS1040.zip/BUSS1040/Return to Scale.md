- How the quantity of output changes when we change the quantity of all of the factors of production
- Diminishing returns is a short run phenomenon

- If output increases proportionally to increase in all input, it's constant returns to scale
- If more, increasing returns to scale
- If less, decreasing returns to scale