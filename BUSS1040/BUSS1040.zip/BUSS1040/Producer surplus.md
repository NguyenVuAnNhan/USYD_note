- Producer surplus is the welfare producers (firms) receive from selling units of a good or service
- Be measured by considering the net benefit of selling a good
- PS = P - Production cost for each unit bought
- A firm's supply curve is given by its MC curve
- A firm's PS can be found by calculating the area between the price line and the firm's supply curve
- Similarly, we can find the PS of all producers in the market by calculating the area between the price line and the market supply curve
![[Pasted image 20240921011312.png]]
