- To analyze welfare in a market further, we introduce the concept of Pareto efficiency
- Pareto efficient means that it is not possible to make someone better off without making someone else worse off
- Maximized total surplus
![[Pasted image 20240921011534.png]]
- Strict definition
- Does not imply uniqueness or fairness/equity