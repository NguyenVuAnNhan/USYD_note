- All factors are variable
	- All costs are variable
	- Alter plant capacity
	- Flexibility, long-run costs should not be more than short-run costs for a given level of output
- Firms will choose:
	- Most efficient production method
	- Cheapest combination of all inputs
![[Pasted image 20240920223640.png]]
![[Pasted image 20240920223652.png]]
