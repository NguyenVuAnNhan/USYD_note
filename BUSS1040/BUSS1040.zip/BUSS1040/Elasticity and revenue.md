- We can determine from the elasticity of demand how total revenue will change as price changes
$$TR(P) = P.q(P)$$
![[Pasted image 20240921015313.png]]
$$\frac{dTR}{dP} = q + P.\frac{dq}{dP}=q(1 + \frac{P}{q}.\frac{dq}{dP})=q(1 + E_d)$$
![[Pasted image 20240921015813.png]]
