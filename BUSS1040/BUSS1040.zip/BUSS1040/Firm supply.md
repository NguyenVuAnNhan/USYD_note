- Quantity of output a firm is willing and able to supply at a certain price
	- The supply curve traces out combinations of market price and quantities willing and able to sell at that price
- Firm supply curve is drawn by changing the price of output, holding all else constant
- Firm should sell up and until P = MC (generate profit)
- ![[Pasted image 20240920230707.png]]
[[The law of supply]]
