- Trade can make everyone better off
- Trade = economic interaction
- Allocate goods to those who value them most. This is the gains from exchange
- Gains from exchange = improvements in income, production, satisfaction due to trade
[[Pareto improving]]

- Trade allows people to take advantage of gains from specialization, reducing overall costs of producing and increasing output

 