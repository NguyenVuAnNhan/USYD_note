Must be barriers to entry
- Legal (exclusive rights, patent)
- Natural (control over source)