- Many buyers and sellers
- Homogenous products
- Price taker
- Free entry and exit
[[Supply in short run]]
[[Supply in long run]]
[[Formulas]]
