- profit = Economic profit = revenues - total opportunity cost
$$\pi = TR - TC$$
Total revenue: the amount a firm receives for the sale of its output
Total cost: amount a firm pays for the input + forgone opportunities