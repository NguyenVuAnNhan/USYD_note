- This is the benefit to market participants
- Markets are one of the main ways that goods and services are produced and distributed
- Consumers and firms will only participate in markets if it is beneficial to them
	- They are at least as well off from trading than if they do not
- We can measure and observe changes in the benefits to these participants using welfare analysis

[[Consumer surplus]]
[[Producer surplus]]

- We can measure the total welfare of all participants in the market
- Total surplus = CS + PS 
![[Pasted image 20240921011409.png]]