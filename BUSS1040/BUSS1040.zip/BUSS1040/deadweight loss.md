- Caused by reducing output from the socially efficient level
	- Higher price transfer surplus from consumers to producers
	- higher price reduces output: causing deadweight loss

- An additional loss: rent seeking behavior
	- Example: bribe to maintain monopoly