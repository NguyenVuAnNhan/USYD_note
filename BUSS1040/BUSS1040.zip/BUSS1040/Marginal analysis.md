- Marginal: something additional or extra\
- MB: additional benefit from consuming one more
- MC: additional cost from producing one more

- Compare MB and MC
- MB > MC: should
- MB < MC: shouldn't