$$\pi = TR - TC$$
$$TR = P*Q$$
$$TC = ATC * Q$$
$$=> \pi = P*Q - ATC * Q = A*(P - ATC)$$

Break-Even
$$TR = TC$$
$$\pi = 0$$
$$P =ATC$$
Make a loss
$$TR < TC$$
$$\pi < 0$$
$$P < ATC$$
![[Pasted image 20240921035033.png]]
