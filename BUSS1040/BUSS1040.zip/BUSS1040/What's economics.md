- The study of choices under scarcity
- What to produce
- How to produce
- Who to consume what is produced

- Typically resolved in [[the market]]
- [[Micro]]
- [[Macro]]

