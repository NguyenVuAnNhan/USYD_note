Resources are limited, not all wants and needs can be met
- Because of scarcity, choices involve a trade-off or [[opportunity cost]]