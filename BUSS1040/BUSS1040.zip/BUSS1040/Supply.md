- Costs to derive an individual firm's supply function and the market supply function
- Focus on competitive market, where both buyers and sellers are price takers

[[Firm supply]]
[[Shift in supply]]
[[Market supply]]
