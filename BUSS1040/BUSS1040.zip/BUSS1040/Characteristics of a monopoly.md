A market with a single seller
- Is a monopoly, the seller is the monopolist
- Only one seller but many buyers
- As the only firm, it has the [[market power]] to be a price maker

[[Reasons for monopoly|Barriers to entry]]
- Cost for new entrant
- Natural or legal
