Single price monopolist
- Same price for each unit of item

Price discrimination
- Different price 