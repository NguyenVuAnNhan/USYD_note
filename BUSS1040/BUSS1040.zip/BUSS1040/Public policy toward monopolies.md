Government want to regulate monopoly

Goal: increases competition

- [[Price regulation]]
- Public ownership
	- Difficult to implement
	- Alter incentives
		- Motivation of private managers different from public ones
		- Assess relative success of public ownership vs regulation
- Do nothing