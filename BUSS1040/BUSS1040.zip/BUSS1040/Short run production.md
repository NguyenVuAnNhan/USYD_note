Average Product of Labor = APL = $$\frac{Y}{L}=\frac{Q}{L}$$
- This is the average output of each worker
Marginal Product of labor = MPL = $$\frac{\Delta Q}{\Delta L} = \frac{\delta Q}{\delta L}$$
- This is the additional output when employing one more worker
- The slope of the production function

![[Pasted image 20240920221434.png]]