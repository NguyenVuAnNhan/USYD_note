- Consumer behavior -> demand for goods and service
- Assume each customer aims to maximize their well-being

[[Benefit and WTP]]
