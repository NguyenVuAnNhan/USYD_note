A market with **a single seller** is a monopoly, the seller is a monopolist

It will use market power to charge higher prices to increase profit
- Downward sloping demand curve, profit-max (MR = MC) implies restricting the quantity traded
- Implication for market failure (DWL)

Regulations possible, unlikely to eliminate all DWL, raise own problems
- Preventative regulation - limit scope of monopolies

A monopolist may increase profit even further by using price discrimination - tailoring prices to specific consumers