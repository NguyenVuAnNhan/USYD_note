Perfect competition
- Price taker
- Produce till P = MC
- P = MR = MC
- no barrier to entry
- no economic profit in long run

Monopolist
- price maker
- produce till MR = MC
- P > MC, P > MR
- barriers to entry
- restrict output, charge higher price and earn economic profits