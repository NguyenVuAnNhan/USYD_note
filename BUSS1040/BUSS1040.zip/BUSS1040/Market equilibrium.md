- A market is in equilibrium if, at the market price, the quantity demanded equals the quantity supplied
- This happens at the market-clearing price (equilibrium price)
![[Pasted image 20240921002721.png]]
- If not in equilibrium, there will be pressure on price and quantity to move towards the equilibrium price and quantity
![[Pasted image 20240921002834.png]]
[[Excess supply]]
![[Pasted image 20240921003040.png]]
[[Excess demand]]

[[Comparative static analysis]]
