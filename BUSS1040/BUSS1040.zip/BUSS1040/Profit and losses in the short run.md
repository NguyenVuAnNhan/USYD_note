- Making a loss -> total revenue is less than total costs
	- P < ATC
- Making profits: TR > TC or P > ATC
	- P - ATC is the average profit made per unit
- A firm is willing to continue to sell in the short run when making a loss as long as $P > AVC_{MIN}$ 
![[Pasted image 20240921030044.png]]
![[Pasted image 20240921030053.png]]
