- A firm's supply curve is given by its MC curve
- as MC curve is upward sloping (LDR)
- This gives a positive relationship between the price of a good and the quantity supplied
- This is the law of supply

- **The law of supply**: There's a positive relationship between price of a good and the quantity supplied, all else constant