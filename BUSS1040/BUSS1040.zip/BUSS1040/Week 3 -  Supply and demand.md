[[Economies of Scale]]
[[Supply]]
[[Demand]]

