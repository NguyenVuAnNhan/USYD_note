- The welfare consumers receive from buying units of a good or service
- We can measure consumer surplus by evaluating the net value of a good as they perceives it
- The consumer surplus = WTP - P
- An individual's CS is by calculating the area between the individual demand curve and the price line
- Similarly, we find the CS of all consumers by calculating the area between the market demand curve and the price line.
![[Pasted image 20240921010346.png]]
