- It's when long-run average costs decrease with output
- Diseconomies of scale is when long-run average costs increases with output
- Constant returns to scale is when long-run average costs are constant as output increases
![[Pasted image 20240920230122.png]]
- Increasing returns to scale implies economy of scale, decreasing returns to scale implies diseconomy of scale
[[Reasons for economy and diseconomy of scale]]
