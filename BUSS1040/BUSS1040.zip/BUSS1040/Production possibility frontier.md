- A PPF graphs the output that an individual or a country can produce with a particular set of resources
- A country's PPF shows all the combinations of goods and services that a country can produce given its resources and its current state of technology
- If no trade, also shows the consumption possibility

- Concave slope: increasing opportunity cost as not all resources can be converted successfully

- Technological improvements shift the cure out (both sides updated) or rotate the curve up or down (one side updated)

- Slope: opportunity cost in term of the other goods
- Dependent on the country's resource and current technology