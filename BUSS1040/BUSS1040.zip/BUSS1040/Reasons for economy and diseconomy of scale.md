Economy
- Labor specialization
- Managerial specialization
- Efficient capital
- Bulk-buying products

Diseconomy
- Duplication of effort
- Top-heavy companies
- Inertia
- Cannibalization
- Inelasticity of supply