[[Marginal cost price regulation]]
[[Average cost price regulation]]
