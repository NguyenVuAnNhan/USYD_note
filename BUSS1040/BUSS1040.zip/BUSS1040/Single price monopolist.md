Same price to all of its customers

Face all demand in the market
- Downward market demand curve
- Has [[Market power|market power]]
- Can choose the price

 Alter price by changing q
 - Downward demand curve
 - increase output -> price fall
	 - Produce more -> price fall
	 - Produce less -> price rise
- Trade off for monopolist

![[Pasted image 20240905014307.png]]

[[Monopolist and marginal revenue]]
[[Monopolist and profit maximization]]
