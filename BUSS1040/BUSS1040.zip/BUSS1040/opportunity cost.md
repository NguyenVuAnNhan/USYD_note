Includes explicit costs and implicit costs
- Explicit: costs involving direct payment
- Implicit: opportunities foregone that do not involve an explicit cost