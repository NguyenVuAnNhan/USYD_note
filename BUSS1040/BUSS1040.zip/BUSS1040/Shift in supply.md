- Any other relevant factors change and the supply curve itself will shift
	- Costs of inputs, technology and expectations about the future
	- At any given output price, the quantity supplied changes
- An increase in supply for shifts to the right, decrease for shift to the left

- Change of the price merely results in movement **along** the supply curve, the curve itself is unchanged