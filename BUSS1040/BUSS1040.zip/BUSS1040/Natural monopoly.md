Results where a single firm can produce for the entire market at cheaper cost than two firm can

Example
- Telecom
- Utility

Reasons
- Declining long run average cost
- High fixed cost, low marginal cost

![[1 firm over 2 firm due to declining average cost.png]]